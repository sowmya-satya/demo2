package com.mindtree.springbootmvc.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class PrizeDto {
	
	
	private int prizeId;
	private String prizeWinType;
	private GameDto game;

	public PrizeDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PrizeDto(int prizeId, String prizeWinType, GameDto game) {
		super();
		this.prizeId = prizeId;
		this.prizeWinType = prizeWinType;
		this.game = game;
	}

	public int getPrizeId() {
		return prizeId;
	}

	public void setPrizeId(int prizeId) {
		this.prizeId = prizeId;
	}

	public String getPrizeWinType() {
		return prizeWinType;
	}

	public void setPrizeWinType(String prizeWinType) {
		this.prizeWinType = prizeWinType;
	}
    @JsonIgnore
	public GameDto getGame() {
		return game;
	}
    
	public void setGameDto(GameDto game) {
		this.game = game;
	}

	


}
