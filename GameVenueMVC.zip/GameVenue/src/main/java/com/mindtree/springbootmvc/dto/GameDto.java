package com.mindtree.springbootmvc.dto;

import java.util.List;

public class GameDto {
	
	private int gameId;
	private String gameName;
	private List<PrizeDto> prize;
	
	private VenueDto venue;

	public GameDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GameDto(int gameId, String gameName, List<PrizeDto> prize, VenueDto venue) {
		super();
		this.gameId = gameId;
		this.gameName = gameName;
		this.prize = prize;
		this.venue = venue;
	}

	public int getGameId() {
		return gameId;
	}

	public void setGameId(int gameId) {
		this.gameId = gameId;
	}

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
   
	public List<PrizeDto> getPrize() {
		return prize;
	}

	public void setPrizeDto(List<PrizeDto> prize) {
		this.prize = prize;
	}
  
	public VenueDto getVenueDto() {
		return venue;
	}

	public void setVenueDto(VenueDto venue) {
		this.venue = venue;
	}

	@Override
	public String toString() {
		return "GameDto [gameId=" + gameId + ", gameName=" + gameName + ", prize=" + prize + ", venue=" + venue + "]";
	}

}
