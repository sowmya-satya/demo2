package com.mindtree.springbootmvc.service;

public interface PrizeService {

}
