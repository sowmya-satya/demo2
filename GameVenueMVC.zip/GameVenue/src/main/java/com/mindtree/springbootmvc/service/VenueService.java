package com.mindtree.springbootmvc.service;

import java.util.List;

import com.mindtree.springbootmvc.dto.GameDto;
import com.mindtree.springbootmvc.dto.VenueDto;

public interface VenueService {

	/**
	 * @param venue
	 * @return venue inserted message
	 */
	public String addVenue(VenueDto venue);

	/**
	 * @return venue details
	 */
	
	public List<VenueDto> venueDetails();

	/**
	 * @param game
	 * @param venueName1
	 * @return insertion details
	 */
	public String addDetails(GameDto game, String venueName);
	
	

}
