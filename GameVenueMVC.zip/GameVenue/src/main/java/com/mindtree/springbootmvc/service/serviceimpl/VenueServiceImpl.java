package com.mindtree.springbootmvc.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.springbootmvc.dto.GameDto;
import com.mindtree.springbootmvc.dto.VenueDto;
import com.mindtree.springbootmvc.entity.Game;
import com.mindtree.springbootmvc.entity.Venue;
import com.mindtree.springbootmvc.repository.GameRepository;
import com.mindtree.springbootmvc.repository.PrizeRepository;
import com.mindtree.springbootmvc.repository.VenueRepository;
import com.mindtree.springbootmvc.service.VenueService;

@Service
public class VenueServiceImpl implements VenueService {

	@Autowired
	VenueRepository venueRepository;
	@Autowired
	GameRepository gameRepository;
	@Autowired
	PrizeRepository PrizeRepository;

	ModelMapper m = new ModelMapper();

	@Override
	public String addVenue(VenueDto venue) {

		Venue v = m.map(venue, Venue.class);

		venueRepository.save(v);

		return "inserted";
	}

	@Override
	public List<VenueDto> venueDetails() {

		List<Venue> venue = venueRepository.findAll();
		List<VenueDto> venue1 = new ArrayList<VenueDto>();

		for (Venue ve : venue) {

			VenueDto v = m.map(ve, VenueDto.class);
			venue1.add(v);

		}

		return venue1;
	}

	@Override
	public String addDetails(GameDto game, String venueName) {

		Venue venue = venueRepository.findByvenueName(venueName);

		Game g = m.map(game, Game.class);

		g.setVenue(venue);

		g.getPrize().forEach(i -> {
			i.setGame(g);
		});

		gameRepository.save(g);

		return "inserted";

	}

}
