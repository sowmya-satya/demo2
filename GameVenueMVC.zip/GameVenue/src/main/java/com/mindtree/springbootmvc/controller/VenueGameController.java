package com.mindtree.springbootmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.springbootmvc.dto.GameDto;
import com.mindtree.springbootmvc.dto.VenueDto;
import com.mindtree.springbootmvc.service.GameService;
import com.mindtree.springbootmvc.service.PrizeService;
import com.mindtree.springbootmvc.service.VenueService;

@Controller
public class VenueGameController {
	
	@Autowired
	GameService gameService;
	@Autowired
	VenueService venueService;
	@Autowired
	PrizeService prizeService;
	
	@RequestMapping("/")
	public String index() {
		
		return "index";
		
	}
	
	@RequestMapping("/addvenue")
	public String addVenue(VenueDto venue) {
		
	  venueService.addVenue(venue);
		
	  return "message";
		
	}

	@RequestMapping("/venue")
	public String venueDetails(Model m) {
		
		List<VenueDto> venue=venueService.venueDetails();
		m.addAttribute("venue",venue);
		
		return "venuepage";
		
	}
	
	String venueName1=null;
	@RequestMapping("/gameadd")
	public String addGameDetails(@RequestParam String venueName,Model m) {
		
		venueName1=venueName;
	m.addAttribute("venueName", venueName);
		
		return "addpage";
		
	}
	
	
	@RequestMapping("/adddetails")
	public String addDetails(GameDto game,String venueName1) {	
	   venueService.addDetails(game,venueName1);
	   
	   return "addpage";
		
	}

    
	

}
