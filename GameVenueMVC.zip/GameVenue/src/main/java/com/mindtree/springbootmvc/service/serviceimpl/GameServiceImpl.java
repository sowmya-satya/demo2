package com.mindtree.springbootmvc.service.serviceimpl;

import org.springframework.stereotype.Service;

import com.mindtree.springbootmvc.service.GameService;
@Service
public class GameServiceImpl implements GameService{

}
