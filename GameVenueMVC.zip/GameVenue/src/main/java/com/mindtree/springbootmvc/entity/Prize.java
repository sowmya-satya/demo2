package com.mindtree.springbootmvc.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;



@Entity
public class Prize {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int prizeId;
	private String prizeWinType;
	
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.REFRESH})
	private Game game;

	public Prize() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Prize(int prizeId, String prizeWinType, Game game) {
		super();
		this.prizeId = prizeId;
		this.prizeWinType = prizeWinType;
		this.game = game;
	}

	public int getPrizeId() {
		return prizeId;
	}

	public void setPrizeId(int prizeId) {
		this.prizeId = prizeId;
	}

	public String getPrizeWinType() {
		return prizeWinType;
	}

	public void setPrizeWinType(String prizeWinType) {
		this.prizeWinType = prizeWinType;
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}

	@Override
	public String toString() {
		return "Prize [prizeId=" + prizeId + ", prizeWinType=" + prizeWinType + ", game=" + game + "]";
	}
	
	
	
	

}
