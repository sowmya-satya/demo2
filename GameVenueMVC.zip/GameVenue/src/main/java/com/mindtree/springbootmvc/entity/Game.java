package com.mindtree.springbootmvc.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Game {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int gameId;
	private String gameName;
	
	@OneToMany(mappedBy="game",cascade= {CascadeType.PERSIST,CascadeType.REFRESH})
	private List<Prize> prize;
	
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.REFRESH})
	private Venue venue;

	public Game() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Game(int gameId, String gameName, List<Prize> prize, Venue venue) {
		super();
		this.gameId = gameId;
		this.gameName = gameName;
		this.prize = prize;
		this.venue = venue;
	}

	public int getGameId() {
		return gameId;
	}

	public void setGameId(int gameId) {
		this.gameId = gameId;
	}

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public List<Prize> getPrize() {
		return prize;
	}

	public void setPrize(List<Prize> prize) {
		this.prize = prize;
	}

	public Venue getVenue() {
		return venue;
	}

	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	@Override
	public String toString() {
		return "Game [gameId=" + gameId + ", gameName=" + gameName + ", prize=" + prize + ", venue=" + venue + "]";
	}
	

}
