package com.mindtree.springbootmvc.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Venue {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int venueId;
	private String venueName;
	
	@OneToMany(mappedBy="venue",cascade=CascadeType.ALL)
	private List<Game> game;

	public Venue() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Venue(int venueId, String venueName, List<Game> game) {
		super();
		this.venueId = venueId;
		this.venueName = venueName;
		this.game = game;
	}

	public int getVenueId() {
		return venueId;
	}

	public void setVenueId(int venueId) {
		this.venueId = venueId;
	}

	public String getVenueName() {
		return venueName;
	}

	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}

	public List<Game> getGame() {
		return game;
	}

	public void setGame(List<Game> game) {
		this.game = game;
	}

	@Override
	public String toString() {
		return "Venue [venueId=" + venueId + ", venueName=" + venueName + ", game=" + game + "]";
	}
	

}
