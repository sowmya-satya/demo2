package com.mindtree.springbootmvc.dto;

import java.util.List;

public class VenueDto {
	

	private int venueId;
	private String venueName;
	private List<GameDto> game;
	
	
	public VenueDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VenueDto(int venueId, String venueName, List<GameDto> game) {
		super();
		this.venueId = venueId;
		this.venueName = venueName;
		this.game = game;
	}

	public int getVenueId() {
		return venueId;
	}

	public void setVenueId(int venueId) {
		this.venueId = venueId;
	}

	public String getVenueName() {
		return venueName;
	}

	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}

	public List<GameDto> getGame() {
		return game;
	}

	public void setGameDto(List<GameDto> game) {
		this.game = game;
	}



}
