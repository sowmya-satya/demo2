package com.mindtree.springbootmvc.service.serviceImpl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.springbootmvc.entity.Department;
import com.mindtree.springbootmvc.entity.Employee;
import com.mindtree.springbootmvc.repository.DepartmentRepository;
import com.mindtree.springbootmvc.repository.EmployeeRepository;
import com.mindtree.springbootmvc.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	DepartmentRepository departmentRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	ModelMapper m=new ModelMapper();

	@Override
	public Employee addEmployeeDetails(Employee employee, String deptName) {
		
		List<Department> department=departmentRepository.findAll();
		
		for(Department dept:department) {
			if(dept.getDeptName().equalsIgnoreCase(deptName)){
				
				employee.setDepartment(dept);
				employeeRepository.save(employee);
			}
		}
				
	
		return employee;
	}
	
	
	@Override
	public List<Department> departmentDetails() {
		
		List<Department> department=departmentRepository.findAll();
		
		return department;
	}
	
	
	
	@Override
	public List<Department> getDetails() {
		List<Department> dep=departmentRepository.findAll();
		return dep;
	}

}
