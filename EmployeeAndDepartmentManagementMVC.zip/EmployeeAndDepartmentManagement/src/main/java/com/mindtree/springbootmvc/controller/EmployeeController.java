package com.mindtree.springbootmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.springbootmvc.entity.Department;
import com.mindtree.springbootmvc.entity.Employee;
import com.mindtree.springbootmvc.service.DepartmentService;
import com.mindtree.springbootmvc.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
      EmployeeService employeeService;
	
	@Autowired
	DepartmentService departmentService;
	
	
	@RequestMapping("/")
	public String departmentDetails(Model m) {
		List<Department> department=employeeService.departmentDetails();
		m.addAttribute("department", department);
		return "department";
	}
	
	
	String departmentName=null;
   @RequestMapping("/employeeadd")
	public String employeeAdd(@RequestParam String deptName,Model m) {
      departmentName=deptName;
      m.addAttribute("deptName", deptName);
		return "addpage";
	}

   
	@RequestMapping("/adddetails")
	public String addEmployeeDetails(Employee employee,Model m) {
		
		employeeService.addEmployeeDetails(employee,departmentName);
	
		return "message";
		
	}
	
	
	
	@RequestMapping("/getdetails")
	public String getEmployeeDetails(Model m) {
		
		List<Department> dep=employeeService.getDetails();
		
		m.addAttribute("dep", dep);
		
		return "getpage";
		
		
		
	}
	
			
}
