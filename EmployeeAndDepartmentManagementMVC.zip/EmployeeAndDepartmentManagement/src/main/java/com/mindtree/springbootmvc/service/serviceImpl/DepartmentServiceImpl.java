package com.mindtree.springbootmvc.service.serviceImpl;

import org.springframework.stereotype.Service;

import com.mindtree.springbootmvc.service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService{

}
