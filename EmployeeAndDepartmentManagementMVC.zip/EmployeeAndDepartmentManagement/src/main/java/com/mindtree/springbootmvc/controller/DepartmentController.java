package com.mindtree.springbootmvc.controller;

import org.springframework.stereotype.Controller;

@Controller
public class DepartmentController {
	

}
