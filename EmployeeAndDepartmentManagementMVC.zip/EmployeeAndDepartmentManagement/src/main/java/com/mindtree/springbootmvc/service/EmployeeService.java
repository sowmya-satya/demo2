package com.mindtree.springbootmvc.service;

import java.util.List;

import com.mindtree.springbootmvc.entity.Department;
import com.mindtree.springbootmvc.entity.Employee;

public interface EmployeeService {

	public Employee addEmployeeDetails(Employee employeeDto, String deptName);

	public List<Department> departmentDetails();

	public List<Department> getDetails();

	
	

}
