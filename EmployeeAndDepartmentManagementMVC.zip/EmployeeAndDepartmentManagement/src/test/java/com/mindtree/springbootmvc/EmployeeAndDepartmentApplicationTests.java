package com.mindtree.springbootmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAndDepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
